# Provenance web media

Shared React components for the emulator websites. Media files and product copy live in the consuming site.

- `@provenance-emu/web-media/hero` renders two gameplay captures and their playback control.
- `@provenance-emu/web-media/gallery` renders a keyboard-accessible device picker and screenshot grid. Each item has a thumbnail, a full-size image, alt text, and optional feature or availability notes.

For a Next.js consumer, add `@provenance-emu/web-media` to `transpilePackages`. Both sites can install the same output of `npm pack`. Commit the versioned tarball and lockfile in each consumer for reproducible builds without registry credentials. Bump the package version before rebuilding the tarball for an update.
