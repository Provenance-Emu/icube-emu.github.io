'use client';

import { useId, useRef, useState } from 'react';
import styles from './media-gallery.module.css';

export type GalleryImage = {
  id: string;
  src: string;
  href: string;
  alt: string;
  width: number;
  height: number;
  caption?: string;
  premium?: string;
  developmentPreview?: boolean;
};

export type GalleryGroup = {
  id: string;
  label: string;
  layout: 'phone' | 'tablet' | 'watch' | 'tv';
  images: GalleryImage[];
};

type Props = {
  brand: 'fly' | 'cube';
  groups: GalleryGroup[];
};

export default function MediaGallery({ brand, groups }: Props) {
  const [selected, setSelected] = useState(0);
  const id = useId();
  const tabs = useRef<HTMLButtonElement[]>([]);
  if (!groups.length) return null;

  return (
    <div className={styles.gallery} data-gallery-brand={brand}>
      <div className={styles.tabs} role="tablist" aria-label="Screenshot devices">
        {groups.map((group, index) => (
          <button
            key={group.id}
            ref={tab => { if (tab) tabs.current[index] = tab; }}
            id={`${id}-tab-${group.id}`}
            type="button"
            role="tab"
            aria-controls={`${id}-panel-${group.id}`}
            aria-selected={selected === index}
            tabIndex={selected === index ? 0 : -1}
            onClick={() => setSelected(index)}
            onKeyDown={event => {
              const last = groups.length - 1;
              let next: number;
              switch (event.key) {
                case 'ArrowRight': next = index === last ? 0 : index + 1; break;
                case 'ArrowLeft': next = index === 0 ? last : index - 1; break;
                case 'Home': next = 0; break;
                case 'End': next = last; break;
                default: return;
              }
              event.preventDefault();
              setSelected(next);
              tabs.current[next]?.focus();
            }}
          >{group.label}</button>
        ))}
      </div>

      {groups.map((group, index) => (
        <div
          key={group.id}
          id={`${id}-panel-${group.id}`}
          role="tabpanel"
          aria-labelledby={`${id}-tab-${group.id}`}
          hidden={index !== selected}
          className={styles.panel}
        >
          <ul className={styles.grid} data-layout={group.layout}>
            {group.images.map(image => (
              <li className={styles.card} key={image.id}>
                <figure>
                  <a href={image.href} target="_blank" rel="noopener noreferrer" aria-label={`Open full-size screenshot: ${image.alt}`}>
                    <img
                      src={image.src}
                      width={image.width}
                      height={image.height}
                      alt={image.alt}
                      loading="lazy"
                      decoding="async"
                    />
                  </a>
                  {(image.caption || image.premium || image.developmentPreview) && (
                    <figcaption>
                      {image.caption}
                      {image.premium && <span className={styles.note}>{image.premium}</span>}
                      {image.developmentPreview && <span className={styles.preview}>Development preview · Not included in the current downloadable build.</span>}
                    </figcaption>
                  )}
                </figure>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
